CREATE TABLE `MessageTable` (
  `messageID` int NOT NULL,
  `senderID` int DEFAULT NULL,
  `recieverID` int DEFAULT NULL,
  `messageContent` varchar(45) DEFAULT NULL,
  `timestamp` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`messageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci